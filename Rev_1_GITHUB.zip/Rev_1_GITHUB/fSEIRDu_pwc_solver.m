function [t,S,E,I,R,D,V]=fSEIRDu_pwc_solver(PAR_vec,t,Y0,N,u,v)
global rho gamma3
fun_ode=@(tt,yy)SEIRDu(tt,yy,PAR_vec,N,u,v,rho, gamma3);
%opt=odeset('NonNegative',1);
%[~,y] = ode45(fun_ode,t,Y0,opt);
[t,y] = ode45(fun_ode,t,Y0);
E=y(:,2);
I=y(:,3);
R=y(:,4);
D=y(:,5);
V=v(t);
S=N-E-I-R-D-V;

function dydt = SEIRDu(t,y,par,N,u,v,rho, gamma3)

alpha=par(1);
beta=par(2);
gamma=par(3);
eta=par(4);
S=y(1);
E=y(2);
I=y(3);
R=y(4);
V=v(t);
U=u(t);
G1=gamma3*R;
G2=rho*beta*I*V/N;
dS_dt=-beta*I*S/N-U+G1;
dE_dt=beta*I*S/N-alpha*E+G2;
dI_dt=alpha*E-gamma*I;
dR_dt=gamma*(1-eta)*I-G1;
dD_dt=eta*gamma*I;
dV_dt=u(t);
dydt = [dS_dt; dE_dt; dI_dt; dR_dt; dD_dt; dV_dt];
end
end