function [t,S,E,I,R,D,V]=fSEIRDV_pwe_solver(par_new,beta0,t,Y0,N,tk1,tk2,u,v)
global rho gamma3
fun_ode = @(tt,yy) fSEIRDV(tt,yy,par_new,beta0,N,tk1,tk2,u,v,rho,gamma3);
%opt=odeset('NonNegative',1);
%[t,y] = ode45(fun_ode,t,Y0,opt);
[t,y] = ode45(fun_ode,t,Y0);
E=y(:,2);
I=y(:,3);
R=y(:,4);
D=y(:,5);
V=v(t);
S=N-E-I-R-D-V;
end
function dydt = fSEIRDV(t,y,par_new,beta0,N,tk1,tk2,u,v,rho,gamma3)
    
betak1=beta0;
betak2=par_new(2);

alpha = par_new(1);
beta  = betafun_exp(betak1,betak2,tk1,tk2,t);
gamma = par_new(3);
eta = par_new(4);
%v= par_new(5);
U=u(t);
S=y(1);
E=y(2);
I=y(3);
R=y(4);
V=v(t);
G1=gamma3*R;
G2=rho*beta*I*V/N;
dS_dt=-beta*I*S/N-U+G1;
dE_dt=beta*I*S/N-alpha*E+G2;
dI_dt=alpha*E-gamma*I;
dR_dt=gamma*(1-eta)*I-G1;
dD_dt=eta*gamma*I;
%dV_dt=U-G2;
dydt = [dS_dt; dE_dt; dI_dt; dR_dt; dD_dt];
end
