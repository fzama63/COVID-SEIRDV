function [beta] = betafun_lin(betak1,betak2,tk1,tk2,t)

for i=1:length(t)
    beta(i) = betak1*(t(i)-tk2)/(tk1-tk2)+betak2*(t(i)-tk1)/(tk2-tk1);
end

end