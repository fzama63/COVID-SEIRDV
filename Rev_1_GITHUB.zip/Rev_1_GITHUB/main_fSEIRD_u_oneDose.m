%
%  Method='levenberg-marquardt';
%  Method='trust-region-reflective';
%
clear all; close all; clc
warning off

addpath ../Common_Functions
Acquisizione_dati;
date=datetime(datestr(xlsread('DATE_prev.xlsx','A1:A749')))+datenum('30-Dec-1899'); 
%
% compute Vaccination speed as Linear Interpolation of the Vaccination  data
%
v_int=griddedInterpolant(1:numel(V),V,'linear');
%
DV=diff(V);DV=[0; DV];% adjust dimensions (backward difference) 
u=griddedInterpolant(1:numel(DV),DV,'linear');
%
 

%% Setting per calibrazione 

ind_inizio=1;
%ind_fine=77;
ind_fine=85;  %21 Marzo 2021
%ind_fine=97; %2 Aprile 2021
global rho gamma3
% rho [0,1] vaccination failure: 0: 100% immunization, 1: 0% immunization
rho=0;
%rho=0.2;
%rho=0.513;%(48.7 efficiency alpha variant one dose ) 
%--------------------------------------------------------------------------
%rho=0.70; % (30% very low eff) 
%rho=0.693;% (30.7 paper alpha variant low eff) 
%rho=0.643;%(35.7 paper alpha variant high eff) 
gamma3=0;
%gamma3=0.005;% probability of immunity loss  after recovery (0: no loss  1: total loss)%
%E0 = 14108; % from SEIRD PWC 8 giorni
%E0=17593;
%E0=11224; % main_E0
E0=11231;
%E0=23477;
%E0=8585; beta viene 1
%E0=16896;
%% Fase 1 : Stimo i parametri iniziali con pwcSEIRDV
%
%  Alternativa: partire dai parametri stimati dal SEIRD
%
%PAR0=0.1*ones(4,1);
%PAR0=[1/6;0.02;1/20;0.03]; % from literature No
PAR0=[1/6;0.02;1/20;0.001];%from literature and E0
% PAR0=[1.;
%    2.4888e-02;
%    3.3586e-02;
%    2.3438e-02;
%    0.1]
 
%PAR0=[1/6;0.02;1/20;0.001];%from literature and E0
 [~,~,~,~,~,~,~,STG,err_rel,OUT]=fSEIRDu_pwc(PAR0,E0,I,R,D,V,N,ind_inizio,ind_inizio+10,11,u,v_int); 
starting_guesses=STG(1:4)
 %%

%% Fase 2 : Determino Dt ottimale per  il modello fSEIRD_u_pwl modello fSEIRD_u_pwe
Method='trust-region-reflective';
%
Intervalli=[5  7  14 16 20 21 23 25 28 42 47 49 60 71 85];j=0;
%
for Tintervals=Intervalli
    beta0=starting_guesses(2); j=j+1; 

    [T_tot_TR,S_tot_TR,E_tot_TR,I_tot_TR,R_tot_TR,D_tot_TR,V_tot_TR,BETA_lin_TR,PAR_tot_TR,err_rel_TR,output_TR]=...
    fSEIRDu_pwl(starting_guesses,beta0,E0,I,R,D,V,N,ind_inizio,ind_fine,Tintervals,u,v_int,Method);
     Res_I_lin=abs(I_tot_TR-I(ind_inizio:ind_fine));MRE_I_lin=sum(Res_I_lin.^2)/numel(Res_I_lin);
     Res_R_lin=abs(R_tot_TR-R(ind_inizio:ind_fine));MRE_R_lin=sum(Res_R_lin.^2)/numel(Res_R_lin);
     Res_D_lin=abs(D_tot_TR-D(ind_inizio:ind_fine));MRE_D_lin=sum(Res_D_lin.^2)/numel(Res_D_lin);
     Res_V_lin=abs(V_tot_TR-V(ind_inizio:ind_fine));MRE_V_lin=sum(Res_V_lin.^2)/numel(Res_V_lin);
     Tab_RRES_pwl(j,:)=sqrt([sum(Res_I_lin.^2)/sum(I(ind_inizio:ind_fine).^2),...
       sum(Res_R_lin.^2)/sum(R(ind_inizio:ind_fine).^2),...
       sum(Res_D_lin.^2)/sum(D(ind_inizio:ind_fine).^2),...
       sum(Res_V_lin.^2)/sum(V(ind_inizio:ind_fine).^2)]);
     %
     [AIC_I_lin, BIC_I_lin] = AIC_BIC(Res_I_lin,numel(PAR_tot_TR),numel(I)+numel(R)+numel(D)+numel(V));
     [AIC_R_lin, BIC_R_lin] = AIC_BIC(Res_R_lin,numel(PAR_tot_TR),numel(I)+numel(R)+numel(D)+numel(V));
     [AIC_D_lin, BIC_D_lin] = AIC_BIC(Res_D_lin,numel(PAR_tot_TR),numel(I)+numel(R)+numel(D)+numel(V));
     [AIC_V_lin, BIC_V_lin] = AIC_BIC(Res_V_lin,numel(PAR_tot_TR),numel(I)+numel(R)+numel(D)+numel(V));
     [AIC_Tot_lin, BIC_Tot_lin] = AIC_BIC([Res_I_lin;Res_R_lin;Res_D_lin],...
         numel(PAR_tot_TR),numel(I)+numel(R)+numel(D)+numel(V));
     Tab_stat_lin(j,:)=[AIC_I_lin, BIC_I_lin,AIC_R_lin, BIC_R_lin,AIC_D_lin, BIC_D_lin,AIC_V_lin, BIC_V_lin,AIC_Tot_lin, BIC_Tot_lin];
     Tab_res_lin(j,:)=[MRE_I_lin, MRE_R_lin, MRE_D_lin, MRE_V_lin];
     Tab_par_lin(j,:)=numel(PAR_tot_TR');
     
     %
     [T_tot_eTR,S_tot_eTR,E_tot_eTR,I_tot_eTR,R_tot_eTR,D_tot_eTR,V_tot_eTR,BETA_exp_eTR,PAR_tot_eTR,err_rel_eTR,output_eTR]=...
    fSEIRDu_pwe(starting_guesses,beta0,E0,I,R,D,V,N,ind_inizio,ind_fine,Tintervals,u,v_int,Method);
     
     
     Res_I_e=abs(I_tot_eTR-I(ind_inizio:ind_fine));MRE_I_e=sum(Res_I_e.^2)/numel(Res_I_e);
     Res_R_e=abs(R_tot_eTR-R(ind_inizio:ind_fine));MRE_R_e=sum(Res_R_e.^2)/numel(Res_R_e);
     Res_D_e=abs(D_tot_eTR-D(ind_inizio:ind_fine));MRE_D_e=sum(Res_D_e.^2)/numel(Res_D_e);
     Res_V_e=abs(V_tot_eTR-V(ind_inizio:ind_fine));MRE_V_e=sum(Res_V_e.^2)/numel(Res_V_e);
     Tab_RRES_pwe(j,:)=sqrt([sum(Res_I_e.^2)/sum(I(ind_inizio:ind_fine).^2),...
       sum(Res_R_e.^2)/sum(R(ind_inizio:ind_fine).^2),...
       sum(Res_D_e.^2)/sum(D(ind_inizio:ind_fine).^2),...
       sum(Res_V_e.^2)/sum(V(ind_inizio:ind_fine).^2)]);
     
     [AIC_I_e, BIC_I_e] = AIC_BIC(Res_I_e,numel(PAR_tot_eTR),numel(I)+numel(R)+numel(D)+numel(V));
     [AIC_R_e, BIC_R_e] = AIC_BIC(Res_R_e,numel(PAR_tot_eTR),numel(I)+numel(R)+numel(D)+numel(V));
     [AIC_D_e, BIC_D_e] = AIC_BIC(Res_D_e,numel(PAR_tot_eTR),numel(I)+numel(R)+numel(D)+numel(V));
     [AIC_V_e, BIC_V_e] = AIC_BIC(Res_V_e,numel(PAR_tot_eTR),numel(I)+numel(R)+numel(D)+numel(V));
     [AIC_Tot_e, BIC_Tot_e] = AIC_BIC([Res_I_e;Res_R_e;Res_D_e],...
         numel(PAR_tot_eTR),numel(I)+numel(R)+numel(D)+numel(V));
    %[T_tot_eTR,S_tot_eTR,E_tot_eTR,I_tot_eTR,R_tot_eTR,D_tot_eTR,V_tot_eTR,BETA_exp_eTR,PAR_tot_eTR,AIC,BIC,err_rel_eTR,output_eTR]=...
  
          Tab_stat_e(j,:)=[AIC_I_e, BIC_I_e,AIC_R_e, BIC_R_e,AIC_D_e, BIC_D_e,AIC_V_e, BIC_V_e,AIC_Tot_e, BIC_Tot_e];
          Tab_res_e(j,:)=[MRE_I_e, MRE_R_e, MRE_D_e, MRE_V_e ];
          Tab_par_e(j,:)=numel(PAR_tot_eTR');
          
   clear PAR_tot_TR PAR_tot_eTR       
end
%--------------------------------------------------------------------------
%
% infetti
%
%%
[MinBIC_l,indx_l]=min(Tab_stat_lin(:,2));
Delta_BIC_I_lin=Tab_stat_lin(:,2)-MinBIC_l;
[MinBIC_e,indx_e]=min(Tab_stat_e(:,2));
Delta_BIC_I_e=Tab_stat_e(:,2)-MinBIC_e;

figure; plot(Intervalli,Delta_BIC_I_lin,'.-b',Intervalli,Delta_BIC_I_e,'.--r','LineWidth',1.5,'MarkerSize',15);title('I');grid on
x_labels=[5 21 37 53 69 85];
y_labels = get(gca, 'YTick'); y_labels = y_labels(2:3:end);
set(gca,'FontSize',17,'fontweight','bold','YTick', y_labels,'YTicklabels',y_labels,'XTick',x_labels,'XTicklabels',x_labels); grid on; %xtickangle(45);

%--------------------------------------------------------------------------
%
% guariti
%
%%
[MinBIC_R_l]=min(Tab_stat_lin(:,4));
Delta_BIC_R_lin=Tab_stat_lin(:,4)-MinBIC_R_l;
[MinBIC_R_e]=min(Tab_stat_e(:,4));
Delta_BIC_R_e=Tab_stat_e(:,4)-MinBIC_R_e;

figure; plot(Intervalli,Delta_BIC_R_lin,'.-b',Intervalli,Delta_BIC_R_e,'.--r','LineWidth',1.5,'MarkerSize',15);title('R');grid on
y_labels = get(gca, 'YTick'); y_labels = y_labels(2:2:end);
set(gca,'FontSize',17,'fontweight','bold','YTick', y_labels,'YTicklabels',y_labels,'XTick',x_labels,'XTicklabels',x_labels); grid on;

%--------------------------------------------------------------------------
%
% morti
%
%%
[MinBIC_D_l]=min(Tab_stat_lin(:,6));
Delta_BIC_D_lin=Tab_stat_lin(:,6)-MinBIC_D_l;
[MinBIC_D_e]=min(Tab_stat_e(:,6));
Delta_BIC_D_e=Tab_stat_e(:,6)-MinBIC_D_e;

figure; plot(Intervalli,Delta_BIC_D_lin,'.-b',Intervalli,Delta_BIC_D_e,'.--r','LineWidth',1.5,'MarkerSize',15);title('D');grid on
y_labels = get(gca, 'YTick'); y_labels = y_labels(1:2:end);
set(gca,'FontSize',17,'fontweight','bold','YTick', y_labels,'YTicklabels',y_labels,'XTick',x_labels,'XTicklabels',x_labels); grid on;

%--------------------------------------------------------------------------
%
% vaccinati
%
%%
% [MinBIC_V_l]=min(Tab_stat_lin(:,8));
% Delta_BIC_V_lin=Tab_stat_lin(:,8)-MinBIC_V_l;
% [MinBIC_V_e]=min(Tab_stat_e(:,8));
% Delta_BIC_V_e=Tab_stat_e(:,8)-MinBIC_V_e;
% 
% figure; plot(Intervalli,Delta_BIC_V_lin,'.-b',Intervalli,Delta_BIC_V_e,'.--r','LineWidth',1.5,'MarkerSize',15);title('V');grid on
% y_labels = get(gca, 'YTick'); y_labels = y_labels(2:2:end);
% set(gca,'FontSize',17,'fontweight','bold','YTick', y_labels,'YTicklabels',y_labels,'XTick',x_labels,'XTicklabels',x_labels); grid on;
% x latex
% sympref('FloatingPointOutput',1);
% LM_row=latex(sym([Fcount_LM Err_mean_LM]))
% eLM_row=latex(sym([Fcount_eLM Err_mean_eLM]))
% TR_row=latex(sym([Fcount_TR Err_mean_TR]))
% eTR_row=latex(sym([Fcount_eTR Err_mean_eTR]))
%% Delta bic totale
Delta_BIC_tot_lin=Delta_BIC_D_lin+Delta_BIC_I_lin+Delta_BIC_R_lin;
Delta_BIC_tot_e=Delta_BIC_D_e+Delta_BIC_I_e+Delta_BIC_R_e;
[Min_Bic_tot_lin,indx_tot_lin]=min(Delta_BIC_tot_lin);
[Min_Bic_tot_e,indx_tot_e]=min(Delta_BIC_tot_e);
figure; plot(Intervalli,Delta_BIC_tot_e,'-.b',Intervalli,Delta_BIC_tot_lin,'--r','LineWidth',1.5,'MarkerSize',15);grid on
y_labels = get(gca, 'YTick'); y_labels = y_labels(2:2:end);
set(gca,'FontSize',17,'fontweight','bold','YTick', y_labels,'YTicklabels',y_labels,'XTick',x_labels,'XTicklabels',x_labels); grid on;
title('\Delta BIC tot')
%--------------------------------------------------------------------------
%%
Max_RES_l=max(Tab_res_lin(:,1));Max_PAR_l=max(Tab_par_lin(:,1));
Max_RES_e=max(Tab_res_e(:,1));Max_PAR_e=max(Tab_par_e(:,1));
Perc_Res_l=100*Tab_res_lin(:,1)/Max_RES_l;Perc_Par=100*Tab_par_lin(:,1)/Max_PAR_l;
Perc_Res_e=100*Tab_res_e(:,1)/Max_RES_e;
%  if Min_Bic_tot_lin <Min_Bic_tot_e
%      Tintervals=Intervalli(indx_tot_lin);
%  else
%      Tintervals=Intervalli(indx_tot_e);
%  end
%==========================================================================
if Intervalli(indx_l)==Intervalli(indx_e)
     Tintervals=Intervalli(indx_l);
else
     Tintervals=round(0.5*(Intervalli(indx_l)+Intervalli(indx_e)));
end
fprintf(' Calibration with Tintervals = %d \n',Tintervals)

%%
fprintf(' Vaccine efficiency : %10.2f perc \n',(1-rho )*100);
fprintf(' Immunity loss after disease : %e probabilty \n',gamma3);
%fprintf(' Optimal calibration interval linear: %d  \n',Intervalli(indx_tot_lin));
%fprintf(' Optimal calibration interval pwe : %d  \n',Intervalli(indx_tot_e));
%fprintf(' Calibration with Tintervals = %d \n',Tintervals);
% %
Tab2_pwl=[ Tab_RRES_pwl(indx_l,1) Tab_stat_lin(indx_l,2) ,...
    Tab_RRES_pwl(indx_l,2) Tab_stat_lin(indx_l,4),...
    Tab_RRES_pwl(indx_l,3) Tab_stat_lin(indx_l,6),...
    Tab_RRES_pwl(indx_l,2) Tab_stat_lin(indx_l,8)];
Tab2_pwe=[ Tab_RRES_pwl(indx_l,1) Tab_stat_lin(indx_l,2) ,...
    Tab_RRES_pwl(indx_l,2) Tab_stat_lin(indx_l,4),...
    Tab_RRES_pwl(indx_l,3) Tab_stat_lin(indx_l,6),...
    Tab_RRES_pwl(indx_l,2) Tab_stat_lin(indx_l,8)];
fprintf('  Lin RRES/BIC   I    R     D     V      \n');
fprintf(' %e ', Tab_RRES_pwl(indx_l,:));fprintf('\n') 
fprintf(' %e ', Tab_stat_lin(indx_l,2: 2:9));fprintf('\n') 
fprintf('  Exp RRES/BIC   I    R     D     V      \n');
fprintf(' %e ',Tab_RRES_pwe(indx_e,:));fprintf('\n'); 
fprintf(' %e ',Tab_stat_e(indx_e,2: 2:9));fprintf('\n'); 

%

%%

%%
    beta0=starting_guesses(2); 

    [T_tot,Lin_S,Lin_E,Lin_I,Lin_R,Lin_D,Lin_V,Lin_BETA,Lin_PAR,Lin_err_rel,output]=...
    fSEIRDu_pwl(starting_guesses,beta0,E0,I,R,D,V,N,ind_inizio,ind_fine,Tintervals,u,v_int,Method);
 %%   
    for i=1:numel(output.frames)
        num_frame(i)=output.frames{i}(1);
        date_frame(i)=date_all(num_frame(i));
        labelsx(i)=date_all(num_frame(i));
    end
     num_frame(i+1)=T_tot(end);
     labelsx(i+1)=date_all(num_frame(i+1));

    [T_tot_e,Exp_S,Exp_E,Exp_I,Exp_R,Exp_D,Exp_V,Exp_BETA,Exp_PAR,Exp_err_rel,output_pwe]=...
        fSEIRDu_pwe(starting_guesses,beta0,E0,I,R,D,V,N,ind_inizio,ind_fine,Tintervals,u,v_int,Method);
 %%   
    Par_pwl=Lin_PAR;
    Par_pwe=Exp_PAR;
    [nr,nc]=size(Par_pwl);
    for i=1:nr
        mu_Lin=mean(Lin_PAR(i,:));
        sigma_Lin=var(Lin_PAR(i,:));
        Lin_PAR(i,nc+1:nc+2)=[mu_Lin,sigma_Lin];   
        mu_Exp=mean(Exp_PAR(i,:));
        sigma_Exp=var(Exp_PAR(i,:));
        Exp_PAR(i,nc+1:nc+2)=[mu_Exp,sigma_Exp];
    end
%%

Lin_Incub_Periods=1./Lin_PAR(1,1:nc)
Lin_Removal_Periods=1./Lin_PAR(3,1:nc)
fprintf('Exp Par \n')
Lin_PAR
sympref('FloatingPointOutput',1);
Lin_Par_all_latex=latex(sym(Lin_PAR))

Exp_Incub_Periods=1./Exp_PAR(1,1:nc)
Exp_Removal_Periods=1./Exp_PAR(3,1:nc)
fprintf('Exp Par \n')
Exp_PAR
sympref('FloatingPointOutput',1);
Exp_Par_all_latex=latex(sym(Exp_PAR))

Mean_Inc_Per=1./(0.5*(Lin_PAR(1,1:nc)+Exp_PAR(1,1:nc)))
Mean_R_P=0.5*(Lin_Removal_Periods+Exp_Removal_Periods)
Mean_Mean_R_P=mean(Mean_R_P) 
Lin_PAR=[];Exp_PAR=[];
Lin_PAR=Par_pwl;
Exp_PAR=Par_pwe;


figure
plot(date_all(T_tot),I(T_tot),'m.','MarkerSize',18,'LineWidth',0.8); hold on;
plot(date_all(T_tot),Lin_I,'--g','LineWidth',2.5); hold on
plot(date_all(T_tot),Exp_I,'-.k','LineWidth',1.5); hold on
ytickformat('%g')
y_labels = get(gca, 'YTick'); y_labels = y_labels(2:2:end);
set(gca,'FontSize',17,'fontweight','bold','YTick', y_labels,'YTicklabels',y_labels,'Xtick',labelsx); grid on; xtickangle(0);
%%
figure
plot(date_all(T_tot),R(T_tot)./1000000,'.-','MarkerSize',18,'Color',[0.96,0.58,0.02],'LineWidth',1.5); hold on;
plot(date_all(T_tot),Lin_R./1000000,'--g','LineWidth',1.5); hold on
plot(date_all(T_tot),Exp_R./1000000,'-.k','LineWidth',1.5); hold on
y_labels = get(gca, 'YTick'); y_labels = y_labels(2:3:end);
set(gca,'FontSize',17,'fontweight','bold','YTick', y_labels,'YTicklabels',y_labels,'Xtick',labelsx); grid on; xtickangle(0);
ytickformat('%g M')
%%
figure
plot(date_all(T_tot),D(T_tot),'.','MarkerSize',18,'Color',[1.00,0.00,0.00],'LineWidth',2); hold on;
plot(date_all(T_tot),Lin_D,'--g','LineWidth',1.5);grid on; 
plot(date_all(T_tot),Exp_D,'-.k','LineWidth',1.5);grid on; 
y_labels = get(gca, 'YTick');
y_labels = y_labels(2:3:end);
set(gca,'FontSize',17,'fontweight','bold','YTick', y_labels,'YTicklabels',y_labels,'Xtick',labelsx); grid on; xtickangle(0);

%%
figure
plot(date_all(T_tot),V(T_tot)./1000000,'.','Color',[0.30,0.75,0.93],'MarkerSize',18,'LineWidth',0.8); hold on;
plot(date_all(T_tot),Lin_V./1000000,'--g','LineWidth',2.5); hold on
plot(date_all(T_tot),Exp_V./1000000,'-.k','LineWidth',1.5); hold on
y_labels = get(gca, 'YTick'); y_labels = y_labels(2:2:end);
set(gca,'FontSize',17,'fontweight','bold','YTick', y_labels,'YTicklabels',y_labels,'Xtick',labelsx); grid on; xtickangle(0);
ytickformat('%g M')
%% 
% Grafici differenze
% figure;
% plot(date_all(T_tot),I(T_tot)-Lin_I,'--g','LineWidth',2.5); hold on
% plot(date_all(T_tot),I(T_tot)-Exp_I,'-.k','LineWidth',1.5);
% y_labels = get(gca, 'YTick'); y_labels = y_labels(2:3:end);
% set(gca,'FontSize',17,'fontweight','bold','YTick', y_labels,'YTicklabels',y_labels,'Xtick',labelsx); grid on; %xtickangle(45);
%%
figure;
plot(date_all(T_tot),Exp_I-Lin_I,'.r','LineWidth',2.5,'MarkerSize',15); hold on
yline(0,'--k','y=0','LineWidth',1.5)
y_labels = get(gca, 'YTick'); y_labels = y_labels(2:3:end);
set(gca,'FontSize',17,'fontweight','bold','YTick', y_labels,'YTicklabels',y_labels,'Xtick',labelsx); grid on; xtickangle(0);
%%
figure;
plot(date_all(T_tot),Exp_E-Lin_E,'.m','LineWidth',2.5,'MarkerSize',15); hold on
yline(0,'--k','y=0','LineWidth',1.5)
y_labels = get(gca, 'YTick');
y_labels = y_labels(2:3:end);
set(gca,'FontSize',17,'fontweight','bold','YTick', y_labels,'YTicklabels',y_labels,'Xtick',labelsx); grid on; xtickangle(0);
%%
% Grafico Rt New
%
GAMMA_Lin=[];GAMMA_Exp=[];
for i=1:numel(output_pwe.frames)
    TT=output_pwe.frames{i};Nt=numel(TT);
    VV=ones(Nt,1)*Exp_PAR(3,i);
    if i > 1, GAMMA_Exp(end)=0.5*(GAMMA_Exp(end)+VV(1));end
    GAMMA_Exp=[GAMMA_Exp; VV(2:end)];
     VV=ones(Nt,1)*Lin_PAR(3,i);
     if i > 1, GAMMA_Lin(end)=0.5*(GAMMA_Lin(end)+VV(1));end
    GAMMA_Lin=[GAMMA_Lin; VV(2:end)];
    VV=[];
end
GAMMA_Exp=[GAMMA_Exp(1);GAMMA_Exp];
GAMMA_Lin=[GAMMA_Lin(1);GAMMA_Lin];
%GAMMA_Exp=mean(Exp_PAR(3,:));
%GAMMA_Lin=mean(Lin_PAR(3,:));
Exp_Rt=Exp_BETA'./GAMMA_Exp;
Lin_Rt=Lin_BETA'./GAMMA_Lin;
Exp_rhoRt=rho*(Exp_BETA'.*u(T_tot)./Exp_S)./GAMMA_Exp;
Lin_rhoRt= rho*(Lin_BETA'.*u(T_tot)./Lin_S)./GAMMA_Lin;
fprintf('rho contrinution to Rt : Lin= %e  Exp = %e \n',...
    max(abs(Lin_rhoRt)),max(abs(Exp_rhoRt)))
 figure
 plot(date_all(T_tot),Exp_Rt,'--r',date_all(T_tot),Exp_rhoRt+Exp_Rt,'-.k')
 figure
 plot(date_all(T_tot),Lin_Rt,'--r',date_all(T_tot),Lin_rhoRt+Lin_Rt,'-.k')
%%
figure
plot(date_all(T_tot),Exp_Rt+Exp_rhoRt,'--r',date_all(T_tot),Lin_Rt+Lin_rhoRt,'-.b','MarkerSize',10,'LineWidth',1.5); hold on
yline(1,'--k','R(t)=1','LineWidth',1.5)
y_labels = get(gca, 'YTick');
y_labels = y_labels(2:2:end);
set(gca,'FontSize',17,'fontweight','bold','YTick', y_labels,'YTicklabels',y_labels,'Xtick',labelsx); grid on; xtickangle(0);
%
figure
plot(date_all(T_tot),Exp_BETA,'--r',date_all(T_tot),Lin_BETA,'-.b','MarkerSize',10,'LineWidth',1.5); hold on
y_labels = get(gca, 'YTick');
y_labels = y_labels(2:3:end);
set(gca,'FontSize',17,'fontweight','bold','YTick', y_labels,'YTicklabels',y_labels,'Xtick',labelsx); grid on; xtickangle(0);
%%
figure
plot(date_all(T_tot),Lin_E,'--g','LineWidth',1.5);grid on; hold on
plot(date_all(T_tot),Exp_E,'-.k','LineWidth',1.5);grid on; 
y_labels = get(gca, 'YTick');
y_labels = y_labels(2:2:end);
set(gca,'FontSize',17,'fontweight','bold','YTick', y_labels,'YTicklabels',y_labels,'Xtick',labelsx); grid on; xtickangle(0);

%% PARTE 4: Figure Previsione
ind_inizio=63;
Ris_Prev_fSEIRDu;
%% FIGURE previsione
labelsx(3)=date_all(ind_fine+30);
stile1={'-.r','-b'}; stile2={'*r','*b'};
figure;
plot(date_all(ind_inizio:ind_fine),I(ind_inizio:ind_fine),'m.','MarkerSize',15,'LineWidth',0.8); hold on
plot(date_all(ind_fine:tk-10), I(ind_fine:tk-10),'om','MarkerSize',5);hold on
plot(date_all(ind_inizio:ind_fine),Lin_I(ind_inizio:ind_fine),'--k','LineWidth',1.5)
hold on; 
for i=1:2
plot(date_all(T_tot(end)-prove_pwl(i)),I(T_tot(end)-prove_pwe(i)),stile2{i},'MarkerSize',15,'LineWidth',2)
plot(date_prev(1:31),I_prev_pwl1(1:31,i),stile1{i},'LineWidth',1.5,'MarkerSize',10);grid on;  axis tight;
end
y_labels = get(gca, 'YTick'); y_labels = y_labels(2:3:end);
set(gca,'FontSize',17,'fontweight','bold','YTick', y_labels,'YTicklabels',y_labels,'XTick',labelsx); grid on; xtickformat('yyyy/MM/dd');


%%
figure;
plot(date_all(ind_inizio:ind_fine),I(ind_inizio:ind_fine),'m.','MarkerSize',15,'LineWidth',0.8); hold on
plot(date_all(ind_fine:tk-10), I(ind_fine:tk-10),'om','MarkerSize',5); hold on
plot(date_all(ind_inizio:ind_fine),Exp_I(ind_inizio:ind_fine),'--k','LineWidth',1.5); hold on; 
for i=1:2
plot(date_all(T_tot(end)-prove_pwe(i)),I(T_tot(end)-prove_pwe(i)),stile2{i},'MarkerSize',15,'LineWidth',2)
plot(date_prev(1:31),I_prev_pwe1(1:31,i),stile1{i},'LineWidth',1.5,'MarkerSize',10);grid on;  axis tight;
end
y_labels = get(gca, 'YTick'); y_labels = y_labels(2:3:end);
set(gca,'FontSize',17,'fontweight','bold','YTick', y_labels,'YTicklabels',y_labels,'XTick',labelsx); grid on; xtickformat('yyyy/MM/dd');


%%
ind_inizio=64;
[Peak_I,day_I]=max(I(ind_fine:tk));
data_Peak_I=date_prev(day_I);
%%
Diff_pwl=max_pwl-Peak_I;Diff_pwe=max_pwe-Peak_I;
Diff_days_pwl=daysact(day_pwl,data_Peak_I);
Diff_days_pwe=daysact(day_pwe,data_Peak_I);
T=table(max_pwl,Diff_pwl,day_pwl,Diff_days_pwl,max_pwe,Diff_pwe,day_pwe,Diff_days_pwe)
%%


labelsx(3)=date_all(ind_fine+giorni);
labelsx(1)=date_all(ind_inizio);
figure; stile={'-k','-.k',':k'};
label{1}='calibration data'; label{2}='acquired data'; label{3}='linear model';
plot(date_all(ind_inizio:ind_fine),I(ind_inizio:ind_fine),'.m','MarkerSize',15); hold on;
plot(date_all(ind_fine:tk),I(ind_fine:tk),'om','MarkerSize',5); axis tight
plot(date_all(ind_inizio:ind_fine),Lin_I(ind_inizio:ind_fine),'--k','LineWidth',1.5); xtickformat('yyyy/MM/dd')
for i=1:length(par_vacc)
plot(date_prev,I_prev_pwl2(:,i),stile{i},'LineWidth',1.5); hold on
label{i+3}=['prevision with ',num2str(sigma(i)),'*v']; %legend(label,'Location','best')
end
y_labels = get(gca, 'YTick'); y_labels = y_labels(2:2:end);
set(gca,'FontSize',17,'fontweight','bold','YTick', y_labels,'YTicklabels',y_labels,'XTick',labelsx); grid on; %xtickangle(45);
%%
% plot Deceased
%
figure; stile={'-k','-.k',':k'};
label{1}='calibration data'; label{2}='acquired data'; label{3}='linear model';
plot(date_all(ind_inizio:ind_fine),D(ind_inizio:ind_fine),'.g','MarkerSize',15); hold on;
plot(date_all(ind_fine:tk),D(ind_fine:tk),'og','MarkerSize',5); axis tight
plot(date_all(ind_inizio:ind_fine),Lin_D(ind_inizio:ind_fine),'--k','LineWidth',1.5); xtickformat('yyyy/MM/dd')
for i=1:length(par_vacc)
plot(date_prev,D_prev_pwl2(:,i),stile{i},'LineWidth',1.5); hold on
label{i+3}=['prevision with ',num2str(sigma(i)),'*v']; %legend(label,'Location','best')
end
y_labels = get(gca, 'YTick'); y_labels = y_labels(2:2:end);
set(gca,'FontSize',17,'fontweight','bold','YTick', y_labels,'YTicklabels',y_labels,'XTick',labelsx); grid on; %xtickangle(45);
%%
% Plot Vaccinated
figure; stile={'-k','-.k',':k'};
label{1}='calibration data'; label{2}='acquired data'; label{3}='linear model';
plot(date_all(ind_inizio:ind_fine),V(ind_inizio:ind_fine),'.','Color',[0.30,0.75,0.93],'MarkerSize',15); hold on;
plot(date_all(ind_fine:tk),V(ind_fine:tk),'o','Color',[0.30,0.75,0.93],'MarkerSize',5); axis tight
plot(date_all(ind_inizio:ind_fine),Lin_V(ind_inizio:ind_fine),'--k','LineWidth',1.5); xtickformat('yyyy/MM/dd')
for i=1:length(par_vacc)
plot(date_prev,V_prev_pwl2(:,i),stile{i},'LineWidth',1.5); hold on
label{i+3}=['prevision with ',num2str(sigma(i)),'*v']; %legend(label,'Location','best')
end
y_labels = get(gca, 'YTick'); y_labels = y_labels(2:2:end);
set(gca,'FontSize',17,'fontweight','bold','YTick', y_labels,'YTicklabels',y_labels,'XTick',labelsx); grid on; %xtickangle(45);

%%
figure
label{3}='exponential model';
plot(date_all(ind_inizio:ind_fine),I(ind_inizio:ind_fine),'.m','MarkerSize',15); hold on;
plot(date_all(ind_fine:tk),I(ind_fine:tk),'om','MarkerSize',5); axis tight
plot(date_all(ind_inizio:ind_fine),Exp_I(ind_inizio:ind_fine),'--k','LineWidth',1.5); xtickformat('yyyy/MM/dd')
for i=1:length(par_vacc)
plot(date_prev,I_prev_pwe2(:,i),stile{i},'LineWidth',1.5); hold on
label{i+3}=['prevision with ',num2str(sigma(i)),'*v']; %legend(label,'Location','best')
end
y_labels = get(gca, 'YTick'); y_labels = y_labels(2:2:end);
set(gca,'FontSize',17,'fontweight','bold','YTick', y_labels,'YTicklabels',y_labels,'XTick',labelsx); grid on; %xtickangle(45);
%%
% plot Deceased
%
figure; stile={'-k','-.k',':k'};
label{1}='calibration data'; label{2}='acquired data'; label{3}='linear model';
plot(date_all(ind_inizio:ind_fine),D(ind_inizio:ind_fine),'.g','MarkerSize',15); hold on;
plot(date_all(ind_fine:tk),D(ind_fine:tk),'og','MarkerSize',5); axis tight
plot(date_all(ind_inizio:ind_fine),Exp_D(ind_inizio:ind_fine),'--k','LineWidth',1.5); xtickformat('yyyy/MM/dd')
for i=1:length(par_vacc)
plot(date_prev,D_prev_pwe2(:,i),stile{i},'LineWidth',1.5); hold on
label{i+3}=['prevision with ',num2str(sigma(i)),'*v']; %legend(label,'Location','best')
end
y_labels = get(gca, 'YTick'); y_labels = y_labels(2:2:end);
set(gca,'FontSize',17,'fontweight','bold','YTick', y_labels,'YTicklabels',y_labels,'XTick',labelsx); grid on; %xtickangle(45);
%%
% Plot Vaccinated
figure; stile={'-k','-.k',':k'};
label{1}='calibration data'; label{2}='acquired data'; label{3}='linear model';
plot(date_all(ind_inizio:ind_fine),V(ind_inizio:ind_fine),'.','Color',[0.30,0.75,0.93],'MarkerSize',15); hold on;
plot(date_all(ind_fine:tk),V(ind_fine:tk),'o','Color',[0.30,0.75,0.93],'MarkerSize',5); axis tight
plot(date_all(ind_inizio:ind_fine),Exp_V(ind_inizio:ind_fine),'--k','LineWidth',1.5); xtickformat('yyyy/MM/dd')
for i=1:length(par_vacc)
plot(date_prev,V_prev_pwe2(:,i),stile{i},'LineWidth',1.5); hold on
label{i+3}=['prevision with ',num2str(sigma(i)),'*v']; %legend(label,'Location','best')
end
y_labels = get(gca, 'YTick'); y_labels = y_labels(2:2:end);
set(gca,'FontSize',17,'fontweight','bold','YTick', y_labels,'YTicklabels',y_labels,'XTick',labelsx); grid on; %xtickangle(45);


Exp_Beta_ave_1=mean(Exp_BETA(1:42));
Exp_Beta_ave_2=mean(Exp_BETA(43:end));
Lin_Beta_ave_2=mean(Lin_BETA(43:end));
Lin_Beta_ave_1=mean(Lin_BETA(1:42));
Lin_Beta_ave=[Lin_Beta_ave_1 Lin_Beta_ave_2]
Exp_Beta_ave=[Exp_Beta_ave_1 Exp_Beta_ave_2]



