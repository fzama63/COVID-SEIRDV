%
%  Grafici Immunità
%
clear all; close all; clc
warning off
ind_inizio=1;
ind_fine=173;

%----------------------
% Acquisizione dati per compartimento V

Tab_vaccini=readtable('updated_data_vaccini_17_giu.csv','Delimiter',',');
Tab_vaccini=sortrows(Tab_vaccini,'data_somministrazione');
date=datetime(Tab_vaccini{:,{'data_somministrazione'}});

% Riunisco i dati regionali giorno per giorno per trattare caso generale Italia
k=1;
prima_dose=0;seconda_dose=0;
for i=1:length(date)-1
    if date(i+1)==date(i)
        prima_dose=prima_dose+Tab_vaccini{i,{'prima_dose'}};
        seconda_dose=prima_dose+Tab_vaccini{i,{'seconda_dose'}};
        Va(k,1)=prima_dose;   testo='One Dose';% Vettore prime dosi somministrate cumulativo
        %V(k,1)=seconda_dose; testo='Two Doses';  % Vettore prime dosi somministrate cumulativo
    else
        k=k+1;
    end  
end
V=Va(ind_inizio:ind_fine);
clear date prima_dose k i Va

% ----------------------
%

Tab = readtable('updated_data_17_giu.csv','Delimiter', ',');
N = 60360000;
Tab=Tab(308:308+ind_fine,:);
date_all = (split(string(Tab{:,1}),'T')); 
date_all = datetime(date_all,'Format','yyyy/MM/dd');


I = Tab{1:numel(V),{'totale_positivi'}};
R = Tab{1:numel(V),{'dimessi_guariti'}};
D = Tab{1:numel(V),{'deceduti'}};
date_all = date_all(1:numel(V));
date=datetime(datestr(xlsread('DATE_prev.xlsx','A1:A749')))+datenum('30-Dec-1899'); 

Delta_I = Tab{1:numel(V),{'nuovi_positivi'}};
%%

%
%
% compute Vaccination speed as Linear Interpolation of the Vaccination  data
%
v_int=griddedInterpolant(1:numel(V),V,'linear');
DV=diff(V);DV=[0; DV];% adjust dimensions (backward difference) 
u=griddedInterpolant(1:numel(DV),DV,'linear');
%
 Method='trust-region-reflective';

%% Setting per calibrazione 

global rho gamma3
rho=0;
% rho [0,1] vaccination failure: 0: 100% immunization, 1: 0% immunization
%rho=0.513;%(48.7 efficiency alpha variant one dose ) 
%--------------------------------------------------------------------------
%rho=0.70; % (30% very low eff) 
 gamma3=0.0;% probability of immunity loss  after recovery (0: no loss  1: total loss)%

E0=11231;
PAR0=[1/6;0.02;1/20;0.001];%from literature and E0
[~,~,~,~,~,~,~,STG,err_rel,OUT]=fSEIRDu_pwc(PAR0,E0,I,R,D,V,N,ind_inizio,ind_inizio+10,11,u,v_int); 
starting_guesses=STG(1:4)

Tintervals=21;
fprintf(' Vaccine efficiency : %10.2f perc \n',(1-rho )*100);
fprintf(' Immunity loss after disease : %e probabilty \n',gamma3);

%
    beta0=starting_guesses(2); 
    [T_tot,Lin_S,Lin_E,Lin_I,Lin_R,Lin_D,Lin_V,Lin_BETA,Lin_PAR,Lin_err_rel,output]=...
    fSEIRDu_pwl(starting_guesses,beta0,E0,I,R,D,V,N,ind_inizio,ind_fine,Tintervals,u,v_int,Method);

     
    for i=1:numel(output.frames)
        num_frame(i)=output.frames{i}(1);
        date_frame(i)=date_all(num_frame(i));
        labelsx(i)=date_all(num_frame(i));
    end
     num_frame(i+1)=T_tot(end);
     labelsx(i+1)=date_all(num_frame(i+1));

    [T_tot_e,Exp_S,Exp_E,Exp_I,Exp_R,Exp_D,Exp_V,Exp_BETA,Exp_PAR,Exp_err_rel,output_pwe]=...
        fSEIRDu_pwe(starting_guesses,beta0,E0,I,R,D,V,N,ind_inizio,ind_fine,Tintervals,u,v_int,Method);
 % 
    Par_pwl=Lin_PAR;
    Par_pwe=Exp_PAR;
  ind_inizio=64;
 %
 % Previsione
 %
  colors = {[0, 0, 1],[0,0.3,0.8],[0, 0.4470, 0.7410],[0,0.5,0.5],[0.3010, 0.7450, 0.9330],[0, 0.75, 0.75],[0, 0.5, 0],[0, 0.7, 0],[0.4,0.7,0],[0.7,0.9,0],[0.75, 0.75, 0],[0.9290, 0.6940, 0.1250],[0.9 0.5 0],[0.8500, 0.3250, 0.0980],[1, 0, 0],[0.6350, 0.0780, 0.1840],[0.5,0,0],[0.5,0,0.5],[0.6,0,0.9],[0.75, 0, 0.75]};%,[0.4940, 0.1840, 0.5560]}


PAR_prev_pwl=Lin_PAR(:,end);
PAR_prev_pwe=Exp_PAR(:,end);
%--------------------------------------------------------------------------
addpath ../SRC_Gen_fSEIRDV/

%sigma=1:5:12; % incremento per par_vacc
sigma=[1, 1.3, 1.5]; 
Days_mean_u=3;
%nu_lin=mean(u(T_tot(end-Days_mean_u:end)))/Lin_S(end);
%nu_exp=mean(u(T_tot(end-Days_mean_u:end)))/Exp_S(end);
nu_lin=mean(u(T_tot(end-Days_mean_u:end)))/mean(Lin_S(end-Days_mean_u:end));
nu_exp=mean(u(T_tot(end-Days_mean_u:end)))/mean(Exp_S(end-Days_mean_u:end));
%%
%nu_val=0.5*(nu_lin+nu_exp);
PAR_prev_pwe=[PAR_prev_pwe; nu_exp];
PAR_prev_pwl=[PAR_prev_pwl; nu_lin];
nu_val=0.5*(nu_lin+nu_exp);
nu_val=nu_val;
%
%par_vacc=PAR_prev_pwl(end)*sigma; % vettore nuovi tassi di vaccinazione 
par_vacc=nu_val*sigma;

giorni=120;
N_cal=numel(T_tot);
t  = T_tot(end);
tk = t+giorni;
date_all=date(1:tk);
T_prev = t:tk;
date_prev=date(T_prev);
Y0_prev_pwl = [Lin_S(N_cal);Lin_E(N_cal);Lin_I(N_cal);Lin_R(N_cal);Lin_D(N_cal);Lin_V(N_cal)];
Y0_prev_pwe = [Exp_S(N_cal);Exp_E(N_cal);Exp_I(N_cal);Exp_R(N_cal);Exp_D(N_cal);Exp_V(N_cal)];
length_last_frame=num_frame(end)-num_frame(end-1);

clear labelsx
labelsx(1)=date(ind_inizio);%date_all(ind_inizio);
labelsx(2)=date(ind_fine);%date_all(ind_fine);
labelsx(3)=date(ind_fine+giorni);%date_all(ind_fine+giorni);

prove_pwl=[1 22];
for i=1:numel(prove_pwl)
    [T_tot_prev,~,E_prev_pwl1(:,i),I_prev_pwl1(:,i),R_prev_pwl1(:,i),D_prev_pwl1(:,i),~]=...
        fSEIRDV_pwl_solver(PAR_prev_pwl,Lin_BETA(N_cal-prove_pwl(i)),T_prev,Y0_prev_pwl,N,T_tot(N_cal-prove_pwl(i)),T_tot(N_cal));
end

prove_pwe=[1 22];
for i=1:numel(prove_pwe)
    [T_tot_prev,~,E_prev_pwe1(:,i),I_prev_pwe1(:,i),R_prev_pwe1(:,i),D_prev_pwe1(:,i),~]=...
        fSEIRDV_pwe_solver(PAR_prev_pwe,Exp_BETA(N_cal-prove_pwe(i)),T_prev,Y0_prev_pwl,N,T_tot(N_cal-prove_pwe(i)),T_tot(N_cal));
end
%  NI_prev=norm(I(T_prev));
%  NR_prev=norm(R(T_prev));
%  ND_prev=norm(D(T_prev));
%  NV_prev=norm(V(T_prev));
%%
for i=1:numel(par_vacc)
    PAR_prev_pwl(end)=par_vacc(i);
    [T_tot_prev,S_prev_pwl2(:,i),E_prev_pwl2(:,i),I_prev_pwl2(:,i),R_prev_pwl2(:,i),D_prev_pwl2(:,i),V_prev_pwl2(:,i)]=fSEIRDV_pwl_solver(PAR_prev_pwl,Lin_BETA(N_cal-1),T_tot_prev,Y0_prev_pwl,N,T_tot(N_cal-1),T_tot(N_cal));
    [val,day]=max(I_prev_pwl2(:,i));
    max_pwl(i,1)=round(val);
    day_pwl(i,1)=date_prev(day);
%     Res_I=I_prev_pwl2(:,i)-I(T_prev);
%     Res_R=R_prev_pwl2(:,i)-R(T_prev);
%     Res_D=D_prev_pwl2(:,i)-D(T_prev);
%     Res_V=V_prev_pwl2(:,i)-V(T_prev);
%     RRES_prev_I=norm(Res_I)/NI_prev;
%     RRES_prev_R=norm(Res_R)/NR_prev;
%     RRES_prev_D=norm(Res_D)/ND_prev;
%     RRES_prev_V=norm(Res_V)/NV_prev;
%     RRES_prev_pwl(i,:)=[RRES_prev_I,RRES_prev_R,RRES_prev_D,RRES_prev_V];
end

for i=1:numel(par_vacc)
    PAR_prev_pwe(end)=par_vacc(i);
    [T_tot_prev,S_prev_pwe2(:,i),E_prev_pwe2(:,i),I_prev_pwe2(:,i),R_prev_pwe2(:,i),D_prev_pwe2(:,i),V_prev_pwe2(:,i)]=fSEIRDV_pwe_solver(PAR_prev_pwe,Exp_BETA(N_cal-1),T_tot_prev,Y0_prev_pwl,N,T_tot(N_cal-1),T_tot(N_cal));
    [val,day]=max(I_prev_pwe2(:,i));
    max_pwe(i,1)=round(val);
    day_pwe(i,1)=date_prev(day);
%     Res_I=I_prev_pwe2(:,i)-I(T_prev);
%     Res_R=R_prev_pwe2(:,i)-R(T_prev);
%     Res_D=D_prev_pwe2(:,i)-D(T_prev);
%     Res_V=V_prev_pwe2(:,i)-V(T_prev);
%     RRES_prev_I=norm(Res_I)/NI_prev;
%     RRES_prev_R=norm(Res_R)/NR_prev;
%     RRES_prev_D=norm(Res_D)/ND_prev;
%     RRES_prev_V=norm(Res_V)/NV_prev;
%     RRES_prev_pwe(i,:)=[RRES_prev_I,RRES_prev_R,RRES_prev_D,RRES_prev_V];
end
%%
labelsx(3)=date(ind_fine+30);
stile1={'-.r','-b'}; stile2={'*r','*b'};
figure;
plot(date_all(ind_inizio:ind_fine),I(ind_inizio:ind_fine),'m.','MarkerSize',15,'LineWidth',0.8); hold on
%plot(date(ind_fine:tk-10), I(ind_fine:tk-10),'om','MarkerSize',5);hold on
plot(date_all(ind_inizio:ind_fine),Lin_I(ind_inizio:ind_fine),'--k','LineWidth',1.5)
hold on; 
for i=1:2
plot(date(T_tot(end)-prove_pwl(i)),I(T_tot(end)-prove_pwe(i)),stile2{i},'MarkerSize',15,'LineWidth',2)
plot(date_prev(1:31),I_prev_pwl1(1:31,i),stile1{i},'LineWidth',1.5,'MarkerSize',10);grid on;  axis tight;
end
y_labels = get(gca, 'YTick'); y_labels = y_labels(2:3:end);
set(gca,'FontSize',17,'fontweight','bold','YTick', y_labels,'YTicklabels',y_labels,'XTick',labelsx); grid on; xtickformat('yyyy/MM/dd');


%%
figure;
plot(date_all(ind_inizio:ind_fine),I(ind_inizio:ind_fine),'m.','MarkerSize',15,'LineWidth',0.8); hold on
%plot(date_all(ind_fine:tk-10), I(ind_fine:tk-10),'om','MarkerSize',5); hold on
plot(date_all(ind_inizio:ind_fine),Exp_I(ind_inizio:ind_fine),'--k','LineWidth',1.5); hold on; 
for i=1:2
plot(date_all(T_tot(end)-prove_pwe(i)),I(T_tot(end)-prove_pwe(i)),stile2{i},'MarkerSize',15,'LineWidth',2)
plot(date_prev(1:31),I_prev_pwe1(1:31,i),stile1{i},'LineWidth',1.5,'MarkerSize',10);grid on;  axis tight;
end
y_labels = get(gca, 'YTick'); y_labels = y_labels(2:3:end);
set(gca,'FontSize',17,'fontweight','bold','YTick', y_labels,'YTicklabels',y_labels,'XTick',labelsx); grid on; xtickformat('yyyy/MM/dd');


%%
%ind_inizio=64;
labelsx(3)=date(ind_fine+giorni);
labelsx(1)=date_all(ind_inizio);
figure; stile={'-k','-.k',':k'};
label{1}='calibration data'; label{2}='acquired data'; label{3}='linear model';
plot(date_all(ind_inizio:ind_fine),I(ind_inizio:ind_fine),'.m','MarkerSize',15); hold on;
%plot(date(ind_fine:tk),I(ind_fine:tk),'om','MarkerSize',5); axis tight
plot(date_all(ind_inizio:ind_fine),Lin_I(ind_inizio:ind_fine),'--k','LineWidth',1.5); xtickformat('yyyy/MM/dd')
for i=1:length(par_vacc)
plot(date_prev,I_prev_pwl2(:,i),stile{i},'LineWidth',1.5); hold on
label{i+3}=['prevision with ',num2str(sigma(i)),'*v']; %legend(label,'Location','best')
end
y_labels = get(gca, 'YTick'); y_labels = y_labels(2:2:end);
set(gca,'FontSize',17,'fontweight','bold','YTick', y_labels,'YTicklabels',y_labels,'XTick',labelsx); grid on; %xtickangle(45);

%%
figure
label{3}='exponential model';
plot(date_all(ind_inizio:ind_fine),I(ind_inizio:ind_fine),'.m','MarkerSize',15); hold on;
%plot(date_all(ind_fine:tk),I(ind_fine:tk),'om','MarkerSize',5); axis tight
plot(date_all(ind_inizio:ind_fine),Exp_I(ind_inizio:ind_fine),'--k','LineWidth',1.5); xtickformat('yyyy/MM/dd')
for i=1:length(par_vacc)
plot(date_prev,I_prev_pwe2(:,i),stile{i},'LineWidth',1.5); hold on
label{i+3}=['prevision with ',num2str(sigma(i)),'*v']; %legend(label,'Location','best')
end
y_labels = get(gca, 'YTick'); y_labels = y_labels(2:2:end);
set(gca,'FontSize',17,'fontweight','bold','YTick', y_labels,'YTicklabels',y_labels,'XTick',labelsx); grid on; %xtickangle(45);
%%
Exp_Beta_ave_1=mean(Exp_BETA(1:42));
Exp_Beta_ave_2=mean(Exp_BETA(43:end));
Lin_Beta_ave_2=mean(Lin_BETA(43:end));
Lin_Beta_ave_1=mean(Lin_BETA(1:42));
Lin_Beta_ave=[Lin_Beta_ave_1 Lin_Beta_ave_2]
Exp_Beta_ave=[Exp_Beta_ave_1 Exp_Beta_ave_2]
%%
% Rt
%
%%
% Grafico Rt New
%
GAMMA_Lin=[];GAMMA_Exp=[];
for i=1:numel(output_pwe.frames)
    TT=output_pwe.frames{i};Nt=numel(TT);
    VV=ones(Nt,1)*Exp_PAR(3,i);
    if i > 1, GAMMA_Exp(end)=0.5*(GAMMA_Exp(end)+VV(1));end
    GAMMA_Exp=[GAMMA_Exp; VV(2:end)];
     VV=ones(Nt,1)*Lin_PAR(3,i);
     if i > 1, GAMMA_Lin(end)=0.5*(GAMMA_Lin(end)+VV(1));end
    GAMMA_Lin=[GAMMA_Lin; VV(2:end)];
    VV=[];
end
GAMMA_Exp=[GAMMA_Exp(1);GAMMA_Exp];
GAMMA_Lin=[GAMMA_Lin(1);GAMMA_Lin];
%GAMMA_Exp=mean(Exp_PAR(3,:));
%GAMMA_Lin=mean(Lin_PAR(3,:));
Exp_Rt=Exp_BETA'./GAMMA_Exp;
Lin_Rt=Lin_BETA'./GAMMA_Lin;
Exp_rhoRt=rho*(Exp_BETA'.*u(T_tot)./Exp_S)./GAMMA_Exp;
Lin_rhoRt= rho*(Lin_BETA'.*u(T_tot)./Lin_S)./GAMMA_Lin;
fprintf('rho contrinution to Rt : Lin= %e  Exp = %e \n',...
    max(abs(Lin_rhoRt)),max(abs(Exp_rhoRt)))

newlabelsx=[date(1) labelsx];
 figure
 plot(date_all(T_tot),Exp_Rt,'--r',date_all(T_tot),Exp_rhoRt+Exp_Rt,'-.k')
 figure
 plot(date_all(T_tot),Lin_Rt,'--r',date_all(T_tot),Lin_rhoRt+Lin_Rt,'-.k')
figure
plot(date_all(T_tot),Exp_Rt+Exp_rhoRt,'--r',date_all(T_tot),Lin_Rt+Lin_rhoRt,'-.b','MarkerSize',10,'LineWidth',1.5); hold on
yline(1,'--k','R(t)=1','LineWidth',1.5)
y_labels = get(gca, 'YTick');
y_labels = y_labels(2:2:end);
set(gca,'FontSize',17,'fontweight','bold','YTick', y_labels,'YTicklabels',y_labels,'Xtick',newlabelsx); grid on; xtickangle(0);
axis tight
%
figure
plot(date_all(T_tot),Exp_BETA,'--r',date_all(T_tot),Lin_BETA,'-.b','MarkerSize',10,'LineWidth',1.5); hold on
y_labels = get(gca, 'YTick');
y_labels = y_labels(2:3:end);
set(gca,'FontSize',17,'fontweight','bold','YTick', y_labels,'YTicklabels',y_labels,'Xtick',newlabelsx); 
grid on; xtickangle(0);

axis tight




%%
figure
label{3}='exponential model'
plot(date_all(ind_inizio:ind_fine),V(ind_inizio:ind_fine)./1000000,'om','MarkerSize',5); hold on;
%plot(date_all(ind_fine:tk),I(ind_fine:tk),'om','MarkerSize',5); axis tight
plot(date_all(ind_inizio:ind_fine),Exp_V(ind_inizio:ind_fine)./1000000,'--k','LineWidth',1.5); xtickformat('yyyy/MM/dd')
%%
for i=1:length(par_vacc)
plot(date_prev,V_prev_pwe2(:,i)./1000000,stile{i},'LineWidth',1.5); hold on
label{i+3}=['prevision with ',num2str(sigma(i)),'*v']; %legend(label,'Location','best')
x_70(i)=date_prev(min(find(round(V_prev_pwe2(:,i))>=N*0.7)));
x_80(i)=date_prev(min(find(round(V_prev_pwe2(:,i))>=N*0.8)));
%x_90(i)=date_prev(min(find(round(V_prev_pwe2(:,i))>=N*0.9)));
end
%%
labelsx(3:5)=sort(x_70,'ascend');
yline(N*0.7/1000000,'--','70 % First Dose                                             ','FontSize',13,'fontweight','bold'); hold on
yline(N*0.8/1000000,'--','80 % First Dose                                             ','FontSize',13,'fontweight','bold')
%yline(N*0.9/1000000,'--','90 % First Dose                                             ','FontSize',13,'fontweight','bold')

%y_labels = get(gca, 'YTick'); y_labels = y_labels(2:2:end);

y_labels(1)=V(end)/1000000;
y_labels(2)=N*0.7/1000000;
y_labels(3)=N*0.8/1000000;
%y_labels(3)=N*0.9/1000000;
set(gca,'FontSize',13,'fontweight','bold','YTick', y_labels);%,'XTick',labelsx); 
grid on; 
xtickangle(45);
ytickformat('%g M'); axis tight
%%
%
fprintf('%s        %s       %s              %s \n','nu','vaccinated per day','70% one dose','80% one dose')
for i=1:length(par_vacc)
fprintf('%10.7f  %i                   %s               %s \n',par_vacc(i),round(par_vacc(i)*N),datestr(x_70(i)),datestr(x_80(i)))
end

%%
figure
label{3}='Linear model'
plot(date_all(ind_inizio:ind_fine),V(ind_inizio:ind_fine)./1000000,'om','MarkerSize',5); hold on;
%plot(date_all(ind_fine:tk),I(ind_fine:tk),'om','MarkerSize',5); axis tight
plot(date_all(ind_inizio:ind_fine),Lin_V(ind_inizio:ind_fine)./1000000,'--k','LineWidth',1.5); xtickformat('yyyy/MM/dd')
for i=1:length(par_vacc)
plot(date_prev,V_prev_pwl2(:,i)./1000000,stile{i},'LineWidth',1.5); hold on
label{i+3}=['prevision with ',num2str(sigma(i)),'*v']; %legend(label,'Location','best')
x_70(i)=date_prev(min(find(round(V_prev_pwl2(:,i))>=round(N*0.7))));
x_80(i)=date_prev(min(find(round(V_prev_pwl2(:,i))>=round(N*0.8))));
%x_90(i)=date_prev(min(find(round(V_prev_pwl2(:,i))>=N*0.9)));
end

labelsx(3:5)=sort(x_70,'ascend');
yline(N*0.7/1000000,'--','70 % First Dose                                             ','FontSize',13,'fontweight','bold'); hold on
yline(N*0.8/1000000,'--','80 % First Dose                                             ','FontSize',13,'fontweight','bold')
%yline(N*0.9/1000000,'--','90 % First Dose                                             ','FontSize',13,'fontweight','bold')
%y_labels = get(gca, 'YTick'); y_labels = y_labels(2:2:end);

y_labels(1)=V(end)/1000000;
y_labels(2)=N*0.7/1000000;
y_labels(3)=N*0.8/1000000;
set(gca,'FontSize',13,'fontweight','bold','YTick', y_labels)%'XTick',labelsx); 
grid on; xtickangle(45);
ytickformat('%g M'); axis tight
%%

fprintf('%s       %s              %s \n','vaccinated per day','70% immunity','80% immunity')
for i=1:length(par_vacc)
fprintf('%i                   %s               %s \n',round(par_vacc(i)*N),datestr(x_70(i)),datestr(x_80(i)))
end
%%
for II=1:3
 indx_l_70(II)=min(find(100*V_prev_pwl2(:,II)/N>=70));
 indx_l_80(II)=min(find(100*V_prev_pwl2(:,II)/N>=80));
 indx_e_70(II)=min(find(100*V_prev_pwe2(:,II)/N>=70));
 indx_e_80(II)=min(find(100*V_prev_pwe2(:,II)/N>=80));
end
%
[indx_l_70 indx_l_80]
[indx_l_70 indx_l_80]
%%
% tabella 5 Infetti
% 
disp('Infects')

    %
 fprintf('\n %d & %10.2f & %d & %10.2f & %d & %10.2f \n',round(I_prev_pwl2(indx_l_70(1),1)), 100*I_prev_pwl2(indx_l_70(1),1)/N,...
     round(I_prev_pwl2(indx_l_70(2),2)), 100*I_prev_pwl2(indx_l_70(2),2)/N,...
     round(I_prev_pwl2(indx_l_70(3),3)), 100*I_prev_pwl2(indx_l_70(3),3)/N);
 % 
   fprintf('\n %d & %10.2f & %d & %10.2f & %d & %10.2f \n',round(I_prev_pwl2(indx_l_80(1),1)), 100*I_prev_pwl2(indx_l_80(1),1)/N,...
     round(I_prev_pwl2(indx_l_80(2),2)), 100*I_prev_pwl2(indx_l_80(2),2)/N,...
     round(I_prev_pwl2(indx_l_80(3),3)), 100*I_prev_pwl2(indx_l_80(3),3)/N);
%
 fprintf('\n %d & %10.2f & %d & %10.2f & %d & %10.2f \n',round(I_prev_pwe2(indx_e_70(1),1)), 100*I_prev_pwe2(indx_e_70(1),1)/N,...
     round(I_prev_pwe2(indx_e_70(2),2)), 100*I_prev_pwe2(indx_e_70(2),2)/N,...
     round(I_prev_pwe2(indx_e_70(3),3)), 100*I_prev_pwe2(indx_e_70(3),3)/N);
%   
 fprintf('\n %d & %10.3f & %d & %10.2f & %d & %10.2f \n',round(I_prev_pwe2(indx_e_80(1),1)), 100*I_prev_pwe2(indx_e_80(1),1)/N,...
     round(I_prev_pwe2(indx_e_80(2),2)), 100*I_prev_pwe2(indx_e_80(2),2)/N,...
     round(I_prev_pwe2(indx_e_80(3),3)), 100*I_prev_pwe2(indx_e_80(3),3)/N); 
%%
disp('Dead')
 fprintf('\n %d & %10.2f & %d & %10.2f & %d & %10.2f \n',round(D_prev_pwl2(indx_l_70(1),1)), 100*D_prev_pwl2(indx_l_70(1),1)/N,...
     round(D_prev_pwl2(indx_l_70(2),2)), 100*D_prev_pwl2(indx_l_70(2),2)/N,...
     round(D_prev_pwl2(indx_l_70(3),3)), 100*D_prev_pwl2(indx_l_70(3),3)/N);
 % 
   fprintf('\n %d & %10.2f & %d & %10.2f & %d & %10.2f \n',round(D_prev_pwl2(indx_l_80(1),1)), 100*D_prev_pwl2(indx_l_80(1),1)/N,...
     round(D_prev_pwl2(indx_l_80(2),2)), 100*D_prev_pwl2(indx_l_80(2),2)/N,...
     round(D_prev_pwl2(indx_l_80(3),3)), 100*D_prev_pwl2(indx_l_80(3),3)/N);
%
 fprintf('\n %d & %10.2f & %d & %10.2f & %d & %10.2f \n',round(D_prev_pwe2(indx_e_70(1),1)), 100*D_prev_pwe2(indx_e_70(1),1)/N,...
     round(D_prev_pwe2(indx_e_70(2),2)), 100*D_prev_pwe2(indx_e_70(2),2)/N,...
     round(D_prev_pwe2(indx_e_70(3),3)), 100*D_prev_pwe2(indx_e_70(3),3)/N);
%   
 fprintf('\n %d & %10.2f & %d & %10.2f & %d & %10.2f \n',round(D_prev_pwe2(indx_e_80(1),1)), 100*D_prev_pwe2(indx_e_80(1),1)/N,...
     round(D_prev_pwe2(indx_e_80(2),2)), 100*D_prev_pwe2(indx_e_80(2),2)/N,...
     round(D_prev_pwe2(indx_e_80(3),3)), 100*D_prev_pwe2(indx_e_80(3),3)/N); 
%%
%
disp('Tabella 5 new')
Tab5_new=[round(I_prev_pwl2(indx_l_70(1),1)) round(D_prev_pwl2(indx_l_70(1),1)) round(I_prev_pwe2(indx_e_70(1),1)) round(D_prev_pwe2(indx_e_70(1),1));
 round(I_prev_pwl2(indx_l_70(2),2)) round(D_prev_pwl2(indx_l_70(2),2)) round(I_prev_pwe2(indx_e_70(2),2)) round(D_prev_pwe2(indx_e_70(2),2)); 
round(I_prev_pwl2(indx_l_70(3),3)) round(D_prev_pwl2(indx_l_70(3),3)) round(I_prev_pwe2(indx_e_70(3),3)) round(D_prev_pwe2(indx_e_70(3),3));
round(I_prev_pwl2(indx_l_80(1),1)) round(D_prev_pwl2(indx_l_80(1),1)) round(I_prev_pwe2(indx_e_80(1),1)) round(D_prev_pwe2(indx_e_80(1),1));
 round(I_prev_pwl2(indx_l_80(2),2)) round(D_prev_pwl2(indx_l_80(2),2)) round(I_prev_pwe2(indx_e_80(2),2)) round(D_prev_pwe2(indx_e_80(2),2));       
round(I_prev_pwl2(indx_l_80(3),3)) round(D_prev_pwl2(indx_l_80(3),3)) round(I_prev_pwe2(indx_e_80(3),3)) round(D_prev_pwe2(indx_e_80(3),3));       
];
    
sympref('FloatingPointOutput',1);
Tab5_new_latex=latex(sym(Tab5_new))

%%
[  round(I_prev_pwl2(indx_l_70(1),1)) round(D_prev_pwl2(indx_l_70(1),1)), round(I_prev_pwl2(indx_l_70(3),1)) round(D_prev_pwl2(indx_l_70(3),1)) ]

 [  round(I_prev_pwl2(indx_l_80(1),1)) round(D_prev_pwl2(indx_l_80(1),1)), round(I_prev_pwl2(indx_l_80(3),1)) round(D_prev_pwl2(indx_l_80(3),1)) ]


% disp('Decessi')
% for II=1:numel(Perc_52_pwl_I)
% fprintf('%d & %10.2f & %d & %10.2f \n',round(D_prev_pwl2(52,II)), Perc_52_pwl_D(II), round(D_prev_pwe2(52,II)), Perc_52_pwe_D(II));
% fprintf('%d & %10.2f & %d & %10.2f \n',round(D_prev_pwl2(89,II)), Perc_89_pwl_D(II), round(D_prev_pwe2(89,II)), Perc_89_pwe_D(II))
% end 
%%
% for II=1:numel(Perc_52_pwl_I)
%    %Num_52l=[round(E_prev_pwl2(52,II)),round(I_prev_pwl2(52,II)),round(R_prev_pwl2(52,II)),round(D_prev_pwl2(52,II))]
%    %Num_52e=[round(E_prev_pwe2(52,II)),round(I_prev_pwl2(52,II)),round(R_prev_pwe2(52,II)),round(D_prev_pwe2(52,II))]
%    %Num_89l=[round(E_prev_pwl2(89,II)),round(I_prev_pwl2(89,II)),round(R_prev_pwl2(89,II)),round(D_prev_pwl2(89,II))]
%    %Num_89e=[round(E_prev_pwe2(89,II)),round(I_prev_pwe2(89,II)),round(R_prev_pwe2(89,II)),round(D_prev_pwe2(89,II))]
%    Num_52l=[round(S_prev_pwl2(52,II)),round(E_prev_pwl2(52,II)),round(I_prev_pwl2(52,II)),round(R_prev_pwl2(52,II)),round(D_prev_pwl2(52,II)),round(V_prev_pwl2(52,II))]
%    Num_52e=[round(S_prev_pwe2(52,II)),round(E_prev_pwe2(52,II)),round(I_prev_pwe2(52,II)),round(R_prev_pwe2(52,II)),round(D_prev_pwe2(52,II)),round(V_prev_pwe2(52,II))]
%    Num_89l=[round(S_prev_pwl2(89,II)),round(E_prev_pwl2(89,II)),round(I_prev_pwl2(89,II)),round(R_prev_pwl2(89,II)),round(D_prev_pwl2(89,II)),round(V_prev_pwl2(89,II))]
%    Num_89e=[round(S_prev_pwe2(89,II)),round(E_prev_pwe2(89,II)),round(I_prev_pwe2(89,II)),round(R_prev_pwe2(89,II)),round(D_prev_pwe2(89,II)),round(V_prev_pwe2(89,II))]
% 
%    [N-sum(Num_52l),N-sum(Num_52e),N-sum(Num_89l),N-sum(Num_89e)]
%        [100*round(Num_52l(6))/N 100*round(Num_89l(6))/N 100*round(Num_52e(6))/N 100*round(Num_89e(6))/N]
%        pause
% end
%%
figure; plot(1:size(I_prev_pwl2,1),I_prev_pwl2(:,1),'--',indx_l_70(1),I_prev_pwl2(indx_l_70(1),1),'*',...
    1:size(I_prev_pwl2,1),I_prev_pwl2(:,2),'-.r',indx_l_70(2),I_prev_pwl2(indx_l_70(2),2),'*r',...
    1:size(I_prev_pwl2,1),I_prev_pwl2(:,3),'-k',indx_l_70(3),I_prev_pwl2(indx_l_70(3),3),'*k')
%%

SI_l(1)=sum(I_prev_pwl2(1:indx_l_70(1),1))
SI_l(2)=sum(I_prev_pwl2(1:indx_l_70(2),2))
SI_l(3)=sum(I_prev_pwl2(1:indx_l_70(3),3))
%
100*SI_l/N
%%
% II=1;indx=indx_l_70(II);
%   Num_l=[round(S_prev_pwl2(indx,II)),round(E_prev_pwl2(indx,II)),round(I_prev_pwl2(indx,II)),round(R_prev_pwl2(indx,II)),round(D_prev_pwl2(indx,II)),round(V_prev_pwl2(indx,II))]
% II=3;indx=indx_e_80(II);
%    Num_e=[round(S_prev_pwe2(indx,II)),round(E_prev_pwe2(indx,II)),round(I_prev_pwe2(indx,II)),round(R_prev_pwe2(indx,II)),round(D_prev_pwe2(indx,II)),round(V_prev_pwe2(indx,II))]
% %
% % figure; bar([Num_52l; Num_52e; Num_89l;Num_89e]);%'stacked'
% labels = {'S','E','I','R','D','V'};explode = [0 1 1 0 1 0];%explode = [0 1 0 1 0 1];
% figure;pie(Num_l,explode); title('SEIRDV pwl 70%');set(gca,'FontSize',15,'fontweight','bold')
% legend('S','E','I','R','D','V','Location','northeast')
% 
% figure;pie(Num_e,explode); title('SEIRDV pwe 80%');set(gca,'FontSize',15,'fontweight','bold')
% legend('S','E','I','R','D','V','Location','northeast')
% %%
% 
% 
% figure
% 
% 
% 
% t = tiledlayout(1,2,'TileSpacing','compact');
% X = categorical({'S','E','I','R','D','V'});
% 
% % Create pie charts
% ax1 = nexttile;pie(Num_l,explode); title('SEIRDV pwl 70%')
% ax2 = nexttile;pie(Num_e,explode); title('SEIRDV pwe 80%')
% %
% lgd = legend(labels);
% lgd.Layout.Tile = 'south';
% set(gca,'FontSize',15,'fontweight','bold')
%--------------------------------------------------------------------------
% %figure; pie(Num_52e);hold on;pie(Num_89e,labels);lgd = legend(labels);
% %lgd.Layout.Tile = 'east';
% 
% figure
% t = tiledlayout(1,2,'TileSpacing','compact');
% 
% % Create pie charts
% ax1 = nexttile;
% 
% pie(Num_52e); title('70% immunisation')
% ax2 = nexttile;pie(Num_89e); title('80% immunisation')
% 
% lgd = legend(labels);
% lgd.Layout.Tile = 'south';

